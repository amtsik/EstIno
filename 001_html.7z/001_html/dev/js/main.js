let welcome = require('./module_1');

welcome('well');


module.exports = function (message) {
    alert(`Welcome ${message}`);
};
